from demovae.sklearn import DemoVAE
