Installable version of DemoVAE demographic-conditioned variational autoencoder for fMRI data.

For use with pip.

Perform fMRI distribution sampling, remove confounds, and harmonize multi-site data.

Supports FC, ALFF, and ReHO data.
